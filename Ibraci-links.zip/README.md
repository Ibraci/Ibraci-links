
TITLE: 
Ibraci Links - Agence Digitale

AUTHOR:
DESIGNED & DEVELOPED by Ibrahim CISSE

Website: https://ibracilinks.ml/
Twitter: http://twitter.com/ibracilinks
Facebook: http://facebook.com/ibracilinks


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/