<?php 

	define ('website_name', 'Ibraci-Links');
	define ('website_url', 'http://localhost');
	define ('website_author', 'Ibrahim CISSE');
	define ('website_legende', 'Agence Digitale');