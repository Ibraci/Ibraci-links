<?php

	require('views/portfolio.view.php');